//
//  EditMeeting.swift
//  Zoom
//
//  Created by Benjamin Who on 2/20/21.
//

import SwiftUI
import CoreData
import Foundation

struct EditMeeting: View {
    
    struct TextFieldClearButton: ViewModifier {
        
        @Binding var text: String
    
        func body(content: Content) -> some View {
            HStack {
                content
                if !text.isEmpty {
                    Button {
                        self.text = ""  }
                        label: {
                            Image(systemName: "multiply.circle.fill")
                                .foregroundColor(Color(UIColor.opaqueSeparator))
                        }.buttonStyle(BorderlessButtonStyle())
                    
                }
            }
        }
    }
    
    
    @Environment(\.managedObjectContext) private var viewContext

    @Binding var isShowingEditMeeting: Bool
    
    @State var focusedTextField = false
    
    @ObservedObject var exsistingMeeting: Item
    
    @State private var meetingStyle = 0
    
    @State var updatedName: String
    @State var updatedDate: Date
    @State var updatedLink: String
    @State var updatedNotes: String
    @State var updatedGoogle: String
    @State var updatedZoom: String
    
    @State var showingAlert = false
    
/*
    init() {
        
        isShowingEditMeeting == true
        
        updatedName = exsistingMeeting.name ?? "Untitled"
        updatedDate = exsistingMeeting.time ?? Date()
        updatedLink = exsistingMeeting.link ?? "No information"
        updatedNotes = exsistingMeeting.notes ?? "Jot down some notes..."
        updatedGoogle = ""
        updatedZoom = ""
    }
 */
    
    var body: some View {
        
        NavigationView {
            
            Form {
                Section(header: Text("Meeting Information"), footer: Text("If you're using a meeting link, make sure it's a URL. Or, use a platform-specific meeting ID. ")) {
                    TextField("Meeting Name", text: $updatedName)
                        .autocapitalization(.words)
                        .modifier(TextFieldClearButton(text: $updatedName))
                        .disableAutocorrection(true)
                    Picker(selection: $meetingStyle, label: Text("Choose a way to add meeting information")) {
                                    Text("Link (URL)").tag(0)
                                       
                                    Text("Zoom").tag(1)
                                        
                                    Text("Google Meet").tag(2)
                                        
                                }
                                .pickerStyle(SegmentedPickerStyle())
                    if meetingStyle == 1 {
                        
                        TextField("Meeting ID", text: $updatedZoom)
                            .keyboardType(.numberPad)
                            .modifier(TextFieldClearButton(text: $updatedZoom))
                    } else if meetingStyle == 0 {
                        TextField("Meeting Link", text: $updatedLink)
                            .modifier(TextFieldClearButton(text: $updatedLink))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                    }
                    else if meetingStyle == 2 {
                        TextField("Meeting ID (include dashes)", text: $updatedGoogle)
                            .modifier(TextFieldClearButton(text: $updatedGoogle))
                    }
                    
                }
                Section(header: Text("Meeting Time")) {
                    DatePicker("Meeting Time", selection: $updatedDate, displayedComponents: [.date, .hourAndMinute])
                        .datePickerStyle(GraphicalDatePickerStyle())
                }
                
                Section(header:
                            
                    HStack {
                        Text("Meeting Notes")
                        Spacer()
                        if focusedTextField == true {
                            Button {
                                hideKeyboard()
                                self.focusedTextField = false
                            } label: {
                                Text("Done")
                                    .foregroundColor(.blue)
                                    .textCase(nil)
                                    .font(.headline)
                            }
                        } else if focusedTextField == false {
                            EmptyView()
                        }
                    }
                
                ) {
                    TextEditor(text: $updatedNotes)
                        .frame(minHeight: 150)
                        .onTapGesture {
                            self.focusedTextField = true
                        }
                }
            }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Can't edit meeting"), message: Text("You've entered more than one meeting destination. For example, you might have put in a URL and a Zoom meeting ID. Please only use one."), dismissButton: .default(Text("Got it")))
            }
            .navigationBarTitle("Edit a Meeting", displayMode: .inline)
            .navigationBarItems(leading: Button {
                self.isShowingEditMeeting = false
                print("Cancelled 'Add Meeting'")
            } label: {
                Text("Cancel")
            }, trailing: Button {
            
                guard updatedName != ""
                else {return}
                guard updatedLink != "" || updatedZoom != "" || updatedGoogle != ""
                else {return}
                
                if updatedLink != "" && updatedGoogle != "" {
                    showingAlert = true
                } else if updatedGoogle != "" && updatedZoom != "" {
                    showingAlert = true
                } else if updatedZoom != "" && updatedLink != "" {
                    showingAlert = true
                } else {
                // Ensure Meeting Name has a value
                let updatedMeeting = exsistingMeeting
                updatedMeeting.name = self.updatedName
                updatedMeeting.notes = self.updatedNotes
                updatedMeeting.time = self.updatedDate
                if updatedLink != "" {
                    updatedMeeting.link = self.updatedLink
                } else if updatedGoogle != "" {
                    updatedMeeting.link = "https://www.meet.google.com/\(self.updatedGoogle)"
                } else if updatedZoom != "" {
                    updatedMeeting.link = "https://www.zoom.us/j/\(self.updatedZoom)"
                }
                
                do {
                        try viewContext.save()
                        print("Successfully edited meeting.")
                    } catch {
                        print(error.localizedDescription)
                    }
                self.isShowingEditMeeting = false
                // Closes Add A New Meeting View
                }
            } label: {
                Text("Save")
            })
            
        }
    }
    
    func clearDate() {
        self.exsistingMeeting.time = Date()
    }
    func clearLink() {
    self.updatedLink = ""
        
    }
    func clearZoom() {
        updatedZoom = ""
    }
    func clearGoogle() {
        updatedGoogle = ""
    }
}

extension Binding where Value == String? {
    func onNon(_ fallback: String) -> Binding<String> {
        return Binding<String>(get: {
            return self.wrappedValue ?? fallback
        }) { value in
            self.wrappedValue = value
        }
    }
}

extension Binding where Value == Date? {
    func onNoneDate(_ fallback: Date) -> Binding<Date> {
        return Binding<Date>(get: {
            return self.wrappedValue ?? fallback
        }) { value in
            self.wrappedValue = value
        }
    }
}

struct EditMeeting_Previews: PreviewProvider {
    
    static let moc = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)

    static var previews: some View {
        let meeting = Item(context: moc)
        meeting.name = "Test Meeting"
        meeting.link = "https://www.zoom.com"
        meeting.time = Date()
        meeting.notes = "These are a lot of ntoes that I took for this meeting. There's prolly some typos but that doesn't really matter because we're in preview mode and this doesn't reflect in the final content."
        return NavigationView {
            EditMeeting(isShowingEditMeeting: Binding.constant(true), exsistingMeeting: meeting, updatedName: "Testing Name", updatedDate: Date(), updatedLink: "https://www.zoom.us/39348399", updatedNotes: "Lorem ipsum dolor.", updatedGoogle: "", updatedZoom: "")
        }
    }
}

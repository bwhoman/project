//
//  AddANewMeeting.swift
//  Zoom
//
//  Created by Benjamin Who on 2/17/21.
//

import SwiftUI

struct AddANewMeeting: View {
    

    struct TextFieldClearButton: ViewModifier {
        
        @Binding var text: String
    
        func body(content: Content) -> some View {
            HStack {
                content
                if !text.isEmpty {
                    Button(
                        action: { self.text = "" },
                        label: {
                            Image(systemName: "multiply.circle.fill")
                                .foregroundColor(Color(UIColor.opaqueSeparator))
                        }
                    )
                }
            }
        }
    }
    
    @ObservedObject var notificationManager = LocalNotificationManager()
    
    @Environment(\.managedObjectContext) private var viewContext
    // Using CoreData managed object
    @Binding var isPresented: Bool
    // Helping Add a New Meeting View
    @State var meetingName = ""
    @State var meetingLink = ""
    @State var meetingID = ""
    @State var meetingGoogle = ""
    @State var meetingTime = Date()
    @State var meetingNotes = "Jot down some notes..."
    // ^^ State variables for form
    
    @State var focusedTextField = false
    
    @State private var addMeetingStyle = 0
    // State variable for Meeting URL or Meeting ID
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Meeting Information"), footer: Text("If you're using a meeting link, make sure it's a URL. You can also use meeting ID's from different platforms.")) {
                    TextField("Meeting Name", text: $meetingName)
                        .autocapitalization(.words)
                        .modifier(TextFieldClearButton(text: $meetingName))
                        .disableAutocorrection(true)
                    Picker(selection: $addMeetingStyle, label: Text("Choose a way to add meeting information")) {
                                    Text("Link (URL)").tag(0)
                                    Text("Zoom").tag(1)
                                    Text("Google Meet").tag(2)
                                }
                                .pickerStyle(SegmentedPickerStyle())
                    if addMeetingStyle == 1 {
                        TextField("Meeting ID (Zoom)", text: $meetingID)
                            .keyboardType(.numberPad)
                    } else if addMeetingStyle == 0 {
                        TextField("Meeting URL", text: $meetingLink)
                            .modifier(TextFieldClearButton(text: $meetingLink))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                    } else if addMeetingStyle == 2 {
                        TextField("Meeting ID (with dashes)", text: $meetingGoogle)
                            .modifier(TextFieldClearButton(text: $meetingGoogle))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                    }
                    
                }
                Section(header: Text("Meeting Time")) {
                    DatePicker("Meeting Time", selection: $meetingTime, displayedComponents: [.date, .hourAndMinute])
                        .datePickerStyle(GraphicalDatePickerStyle())
                }
                
                Section(header:
                            
                    HStack {
                        Text("Meeting Notes")
                        Spacer()
                        if focusedTextField == true {
                            Button {
                                hideKeyboard()
                                self.focusedTextField = false
                            } label: {
                                Text("Done")
                                    .foregroundColor(.blue)
                                    .textCase(nil)
                                    .font(.headline)
                            }
                        } else if focusedTextField == false {
                            EmptyView()
                        }
                    }
                
                ) {
                    TextEditor(text: $meetingNotes)
                        .frame(minHeight: 150)
                        .onTapGesture {
                            self.focusedTextField = true
                        }
                }
            }
            .navigationBarTitle("Add a New Meeting", displayMode: .inline)
            .navigationBarItems(leading: Button {
                self.isPresented = false
                print("Cancelled 'Add Meeting'")
            } label: {
                Text("Cancel")
            }, trailing: Button {
            
                guard self.meetingName != "" else {return}
                guard meetingLink != "" || meetingID != "" || meetingGoogle != "" else {return}
                // Ensure Meeting Name has a value
                let newMeeting = Item(context: viewContext)
                newMeeting.name = self.meetingName
                if meetingLink != "" {
                    newMeeting.link = self.meetingLink
                } else if meetingID != "" {
                    newMeeting.link = "https://www.zoom.us/j/\(self.meetingID)"
                } else if meetingGoogle != "" {
                    newMeeting.link = "https://www.meet.google.com/\(self.meetingGoogle)"
                }
                // Logic for choosing between Meeting ID and Meeting Link
                newMeeting.time = self.meetingTime
                newMeeting.notes = self.meetingNotes
                do {
                        try viewContext.save()
                        print("New Meeting Created")
                    } catch {
                        print(error.localizedDescription)
                    }
                self.notificationManager.sendNotification(title: "Upcoming Meeting", subtitle: nil, body: "\(meetingName) will start in 5 minutes. Tap here to get meeting information.", time: meetingTime, meetingName: "\(newMeeting.link ?? "Undefined")")
                self.isPresented = false
                // Closes Add A New Meeting View
            } label: {
                Text("Create")
            })
            
        }
    }
    func clearDate() {
        self.meetingTime = Date()
    }
}


struct AddANewMeeting_Previews: PreviewProvider {
    static var previews: some View {
        AddANewMeeting(isPresented: Binding.constant(true))
    }
}

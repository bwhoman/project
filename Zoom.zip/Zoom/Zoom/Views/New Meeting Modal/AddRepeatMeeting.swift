//
//  AddRepeatMeeting.swift
//  Zoom
//
//  Created by Benjamin Who on 2/19/21.
//

import SwiftUI

import SwiftUI

struct AddRepeatMeeting: View {
    
    struct StoreReviewHelper {
    }

    struct UserDefaultsKeys {
        static let APP_OPENED_COUNT = "APP_OPENED_COUNT"
    }

    struct TextFieldClearButton: ViewModifier {
        
        @Binding var text: String
    
        func body(content: Content) -> some View {
            HStack {
                content
                if !text.isEmpty {
                    Button(
                        action: { self.text = "" },
                        label: {
                            Image(systemName: "multiply.circle.fill")
                                .foregroundColor(Color(UIColor.opaqueSeparator))
                        }
                    )
                }
            }
        }
    }
    
    @Environment(\.managedObjectContext) private var viewContext
    // Using CoreData managed object
    @Binding var isPresentedRepeat: Bool
    // Helping Add a New Meeting View
    @State var meetingName = ""
    @State var meetingLink = ""
    @State var meetingID = ""
    @State var meetingTime = Date()
    @State var meetingNotes = ""
    @State var repeats = ""
    @State var meetingGoogle = ""
    @State var complainNoMeetingName = false
    @State var complainNoMeetingAccessibles = false
    @State var complainEverything = false
    @State var complainNoMeetingRepeat = false
    // ^^ State variables for form
    
    @State private var addMeetingStyle = 0
    // State variable for Meeting URL or Meeting ID
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Meeting Information"), footer: Text("If you're using a meeting link, make sure it's a URL. If you only have a Zoom meeting ID, that works also. ")) {
                    TextField("Meeting Name", text: $meetingName)
                        .autocapitalization(.words)
                        .modifier(TextFieldClearButton(text: $meetingName))
                        .disableAutocorrection(true)
                    Picker(selection: $addMeetingStyle, label: Text("Choose a way to add meeting information")) {
                                    Text("Link (URL)").tag(0)
                                    Text("Zoom").tag(1)
                                    Text("Google Meet").tag(2)
                                }
                                .pickerStyle(SegmentedPickerStyle())
                    if addMeetingStyle == 1 {
                        TextField("Meeting ID", text: $meetingID)
                            .keyboardType(.numberPad)
                    } else if addMeetingStyle == 0 {
                        TextField("Meeting Link", text: $meetingLink)
                            .modifier(TextFieldClearButton(text: $meetingLink))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                    } else if addMeetingStyle == 2 {
                        TextField("Meeting ID (include dashes)", text: $meetingGoogle)
                            .modifier(TextFieldClearButton(text: $meetingGoogle))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                    }
                    
                }
                Section(header: Text("Meeting Time")) {
                    DatePicker("Meeting Time", selection: $meetingTime, displayedComponents: [.hourAndMinute])
                        .datePickerStyle(DefaultDatePickerStyle())
                    Picker("Repeats", selection: $repeats) {
                        Text("Every Sunday").tag("1")
                        Text("Every Monday").tag("2")
                        Text("Every Tuesday").tag("3")
                        Text("Every Wednesday").tag("4")
                        Text("Every Thursday").tag("5")
                        Text("Every Friday").tag("6")
                        Text("Every Saturday").tag("7")
                        Text("Weekdays").tag("8")
                        Text("Weekends").tag("9")
                        Text("Daily").tag("10")
                    }
                    
                }
                Section(header: Text("Meeting Notes")) {
                    TextEditor(text: $meetingNotes)
                        .frame(minHeight: 150)
                }
            }
            .background(EmptyView()
            .alert(isPresented: $complainNoMeetingName) {
                Alert(title: Text("Can't create meeting"), message: Text("Meetings need to have a name. Please enter a name for this meeting."), dismissButton: .default(Text("Ok")))
            })
            .background(EmptyView()
            .alert(isPresented: $complainNoMeetingAccessibles) {
                Alert(title: Text("Can't create meeting"), message: Text("Meetings needs a way to access your meeting. Please enter either a URL, Zoom meeting ID, or a Google Meet ID."), dismissButton: .default(Text("Ok")))
            })
            .background(EmptyView()
            .alert(isPresented: $complainEverything) {
                Alert(title: Text("Can't create meeting"), message: Text("Please enter a meeting name and either a meeting URL, Zoom Meeting ID, or Google Meet ID."), dismissButton: .default(Text("Ok")))
            })
            .background(EmptyView()
            .alert(isPresented: $complainNoMeetingRepeat) {
                Alert(title: Text("Can't create meeting"), message: Text("Repeating meetings must have a repeat pattern. Please specify how often this meeting repeats."), dismissButton: .default(Text("Ok")))
            })
            .navigationBarTitle("Add a New Meeting", displayMode: .inline)
            .navigationBarItems(leading: Button {
                self.isPresentedRepeat = false
                print("Cancelled 'Add Meeting'")
            } label: {
                Text("Cancel")
            }, trailing: Button {
            
                if (meetingName == "") && (meetingLink == "" && meetingID == "" && meetingGoogle == "") {
                    complainEverything = true
                    print("Can't add meeting because user has not specified meeting name or accessibles.")
                } else if
                meetingLink == "" && meetingID == "" && meetingGoogle == "" {
                    complainNoMeetingAccessibles = true
                    print("Can't add meeting because user has not specified meeting accessibles.")
                } else if meetingName == "" {
                    complainNoMeetingName = true
                    print("Can't add meeting because user has not specified meeting name.")
                } else if repeats == "" {
                    complainNoMeetingRepeat = true
                    print("Can't add meeting because user has not specified a meeting repeat.")
                } else {
                print("Meeting contains necessary information, doing further checking now...")
                // Ensure Meeting Name has a value
                let newMeeting = RepeatingItem(context: viewContext)
                newMeeting.name = self.meetingName
                if meetingLink != "" {
                    newMeeting.link = self.meetingLink
                } else if meetingID != "" {
                    newMeeting.link = "https://www.zoom.us/j/\(self.meetingID)"
                } else if meetingGoogle != "" {
                    newMeeting.link = "https://www.meet.google.com/\(self.meetingGoogle)"
                }
                // Logic for choosing between Meeting ID and Meeting Link
                newMeeting.time = self.meetingTime
                newMeeting.repeats = self.repeats
                newMeeting.notes = self.meetingNotes
                do {
                        try viewContext.save()
                        print("New Repeating Meeting Created")
                    } catch {
                        print(error.localizedDescription)
                    }
                self.isPresentedRepeat = false
                // Closes Add A New Meeting View
                }
            } label: {
                Text("Create")
            })
        }
    }
    func clearDate() {
        self.meetingTime = Date()
    }
}


struct AddRepeatMeeting_Previews: PreviewProvider {
    static var previews: some View {
        AddRepeatMeeting(isPresentedRepeat: Binding.constant(true))
    }
}

//
//  MeetingsDetailView.swift
//  Zoom
//
//  Created by Benjamin Who on 2/14/21.
//

import SwiftUI
import CoreData

struct MeetingsDetailView: View {
    
    @ObservedObject var audioRecorder: AudioRecorder

    @Environment(\.openURL) var openURL
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var meeting: Item
    
    @State private var showingActionSheet = false
    @State var backToContentView = false
    @State var focusedTextField = false
    
    @State var isShowingEditMeeting = false
    
    var body: some View {
                List {
                Section(header:
                    HStack {
                        Text("Meeting Information")
                            .font(.headline)
                            .textCase(nil)
                            .onAppear {
                                AppReviewRequest.requestReviewIfNeeded()
                            }
                        Spacer()
                        Button {
                            print("Edit meeting")
                            self.isShowingEditMeeting.toggle()
                        } label : {
                            Text("Edit")
                            .foregroundColor(Color.blue)
                            .textCase(nil)
                            .font(.headline)
                            
                        }
                    }
                ) {
                    HStack {
                        Text("Meeting Name")
                        Spacer()
                        Text("\(self.meeting.name ?? "Untitled")")
                    }
                    HStack {
                        Text("Meeting Time")
                        Spacer()
                        Text("\(self.meeting.time ?? Date(), formatter: itemFormatter)")
                    }
                    HStack {
                        Text("Meeting Info")
                            .padding(.trailing, 40)
                        Spacer()
                            
                        Text("\(self.meeting.link ?? "No information")")
                            .multilineTextAlignment(.trailing)
                            .fixedSize(horizontal: false, vertical: true)
                            
                            
                    }
                   
                }
                Section(header:
                                
                    HStack {
                        Text("Meeting Notes")
                            .font(.headline)
                            .textCase(nil)
                        Spacer()
                        if focusedTextField == true {
                            Button {
                                hideKeyboard()
                                self.focusedTextField = false
                            } label: {
                                Text("Done")
                                    .foregroundColor(.blue)
                                    .textCase(nil)
                                    .font(.headline)
                            }
                        } else if focusedTextField == false {
                            EmptyView()
                        }
                    }) {
                        ZStack {
                            TextEditor(text:  $meeting.notes.onNonee(""))
                                .frame(minHeight: 100)
                                .onTapGesture {
                                    self.focusedTextField = true
                                }
                            Text(meeting.notes ?? "")
                                .opacity(0)
                                .padding(.all, 8)
                        }
                    }
                    .onDisappear() {
                        do {
                            try viewContext.save()
                            print("Meeting information updated.")
                        } catch {
                            print(error.localizedDescription)
                        }
                    }
                 
                Section(header: Text("Recording Studio")
                            .font(.headline)
                            .textCase(nil)
                ) {
                    
                    ForEach(audioRecorder.recordings, id: \.createdAt) { recording in
                    RecordingRow(audioURL: recording.fileURL)
                    }
                    .onDelete(perform: delete)
                    
                    
                    HStack {
                        Spacer()
                        if audioRecorder.recording == false {
                            Button(action: {
                                self.audioRecorder.startRecording()
                                print("Start recording")
                            
                            }) {
                                Image(systemName: "largecircle.fill.circle")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 40, height: 40)
                                    .clipped()
                                    .foregroundColor(.red)
                                    .padding(.bottom, 10)
                                    .padding(.top, 10)
                            }.buttonStyle(BorderlessButtonStyle())
                        } else {
                            Button(action: {
                                self.audioRecorder.stopRecording()
                                    print("Stop recording)")
                                        
                                
                            }) {
                                Image(systemName: "stop.circle")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 40, height: 40)
                                    .clipped()
                                    .foregroundColor(.red)
                                    .padding(.bottom, 10)
                                    .padding(.top, 10)
                            }.buttonStyle(BorderlessButtonStyle())
                        }
                        Spacer()
                    }
                }
                Section(header: Text("Actions")
                        .font(.headline)
                        .textCase(nil)
                ) {
                    HStack {
                        Button(action: {
                            print("User wants to join meeting.")
                            openURL(URL(string: "\(meeting.link ?? "untitled")")!)
                        }, label: {
                            HStack {
                                Image(systemName: "arrow.up.right")
                                    .foregroundColor(Color.blue)
                                Text("Join meeting")
                                    .foregroundColor(Color.blue)
                                Spacer()
                            }
                            
                        })
                        Spacer()
                    }
                    HStack {
                        Button(action: {
                            print("User wants to share meeting.")
                            guard let data = URL(string: "\(meeting.link ?? "Undefined")") else {return}
                            let av = UIActivityViewController(activityItems: [data], applicationActivities: nil)
                            UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)
                        }, label: {
                            HStack {
                                Image(systemName: "square.and.arrow.up")
                                    .foregroundColor(Color.blue)
                                Text("Share meeting")
                                    .foregroundColor(Color.blue)
                                Spacer()
                            }
                            
                        })
                        Spacer()
                    }
                    HStack {
                        Button(action: {
                            print("User wants to delete meeting.")
                            showingActionSheet = true
                        }, label: {
                            HStack {
                                Image(systemName: "trash")
                                    .foregroundColor(Color.red)
                                Text("Delete this meeting")
                                    .foregroundColor(Color.red)
                            }
                        })
                        Spacer()
                    }
                    
                }
            }

            .listStyle(InsetGroupedListStyle())
            .navigationTitle("\(self.meeting.name ?? "Untitled")")
            .navigationViewStyle(DefaultNavigationViewStyle())
            
            .actionSheet(isPresented: $showingActionSheet) {
                        ActionSheet(
                            title: Text("Delete this meeting?"),
                            buttons: [.destructive(Text("Delete Meeting"),
                                action: {
                                    print(123)
                                    self.viewContext.delete(self.meeting)
                                    do {
                                        try self.viewContext.save()
                                        
                                        } catch {
                                            print(error)
                                        }
                                }
                            ), .cancel()]
                            
                        )
        }
            .sheet(isPresented: $isShowingEditMeeting, content: {
                EditMeeting(isShowingEditMeeting: $isShowingEditMeeting, exsistingMeeting: meeting, updatedName: "\(meeting.name ?? "Untitled")", updatedDate: meeting.time ?? Date(), updatedLink: "\(meeting.link ?? "No information")", updatedNotes: "\(meeting.notes ?? "")", updatedGoogle: "", updatedZoom: "")
                    
                })
    }
    
    func delete(at offsets: IndexSet) {
            
        var urlsToDelete = [URL]()
        for index in offsets {
            urlsToDelete.append(audioRecorder.recordings[index].fileURL)
        }
        audioRecorder.deleteRecording(urlsToDelete: urlsToDelete)
        }
    
    private let itemFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter
    }()
}

extension Binding where Value == String? {
    func onNonee(_ fallback: String) -> Binding<String> {
        return Binding<String>(get: {
            return self.wrappedValue ?? fallback
        }) { value in
            self.wrappedValue = value
        }
    }
}

#if canImport(UIKit)
extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
#endif

struct MeetingsDetailView_Previews: PreviewProvider {
    
    static let moc = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
    
    
    static var previews: some View {
        
        let meeting = Item(context: moc)
        meeting.name = "Meeting with Jackie"
        meeting.link = "https://www.zoom.com"
        meeting.time = Date()
        meeting.notes = "These are a lot of ntoes that I took for this meeting. There's prolly some typos but that doesn't really matter because we're in preview mode and this doesn't reflect in the final content."
        
        
        return NavigationView {
            MeetingsDetailView(audioRecorder: AudioRecorder(), meeting: meeting)
        }

    }
    
}


// detailMeetingName: "Sample Meeting", meeting: <#Item#>, detailMeetingLink: "https://www.zoom.us/j/2309384201",  detailMeetingTime: Date(), detailMeetingNotes: "These are a lot of ntoes that I took for this meeting. There's prolly some typos but that doesn't really matter because we're in preview mode and this doesn't reflect in the final content."

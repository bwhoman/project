//
//  ContentViewProtection.swift
//  Zoom
//
//  Created by Benjamin Who on 2/17/21.
//

/*

import SwiftUI
import CoreData
import Foundation
import StoreKit


// MARK: Content View Structure
struct ContentView: View {
    
    @State private var showWhatsNew = false

       // Get current Version of the App
       func getCurrentAppVersion() -> String {
           let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"]
           let version = (appVersion as! String)

           return version
       }

       // Check if app if app has been started after update
       func checkForUpdate() {
           let version = getCurrentAppVersion()
           let savedVersion = UserDefaults.standard.string(forKey: "savedVersion")

           if savedVersion == version {
               print("App is up to date!")
           } else {

               // Toogle to show WhatsNew Screen as Modal
               self.showWhatsNew.toggle()
               UserDefaults.standard.set(version, forKey: "savedVersion")
           }
       }
   
    @AppStorage("Onboarding View") var isShowingOnboardingScreen = true
    // Show onboarding view?
    @Environment(\.openURL) var openURL
    //
    @State var isPresentingAddMeetingScreen = false
    // Boolean for Add Meeting Screen
    @Environment(\.managedObjectContext) private var viewContext
    // Using CoreData managed object
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Item.time, ascending: true)],
        animation: .default)
    private var items: FetchedResults<Item>
    // Fetch Request return: items

    // MARK: Content View Body
    var body: some View {
    // If statement:
            if items.count == 0 {
                NavigationView {
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                                .frame(width: 40)
                            Text("You have no meetings. To add a meeting, click the +.")
                                .font(.body)
                                .foregroundColor(Color.gray)
                                .multilineTextAlignment(.center)
                            Spacer()
                                .frame(width: 40)
                        }
                        Spacer()
                    }
                    .navigationTitle("My Meetings")
                    .navigationBarItems(trailing:
                        Button {
                            self.isPresentingAddMeetingScreen.toggle()
                        } label: {
                            Image(systemName: "plus")
                        })
                    .navigationTitle("My Meetings")
                    .sheet(isPresented: $isPresentingAddMeetingScreen, content: {
                        AddANewMeeting(isPresented: self.$isPresentingAddMeetingScreen)
                    })
                    .background(EmptyView()
                        .sheet(isPresented: $isShowingOnboardingScreen, content: { IntroductionView(isShowingOnboardingScreen: $isShowingOnboardingScreen)
                    }))
                }
            // MARK: Else
            } else {
            NavigationView {
                List {
                    ForEach(items) { item in
                    HStack {
                        VStack(alignment: .leading){
                            Text("\(item.name ?? "Untitled")")
                                .font(.largeTitle)
                                .padding(.top, 5.0)
                                .padding(.bottom, 2)
                            Text("Meeting begins at \(item.time!, formatter: itemFormatter)")
                                .padding(.bottom, 3.0)
                        }
                        Spacer()
                        Button {
                            print("Sending to computer")
                            guard let data = URL(string: "\(item.link ?? "undefined")") else { return }
                            let av = UIActivityViewController(activityItems: [data], applicationActivities: nil)
                            UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)
                        } label: {
                            Image(systemName: "wave.3.right.circle.fill")
                                .font(.title)
                                .padding(.trailing, 1)
                        }
                        .buttonStyle(BorderlessButtonStyle())
                        Button {
                            print("Joining on iPhone")
                            openURL(URL(string: "\(item.link ?? "untitled")")!)
                        } label: {
                            Text("JOIN")
                                .fontWeight(.semibold)
                                .foregroundColor(Color.white)
                                .frame(width: 60.0, height: 30.0)
                                .padding(.trailing, 1.0)
                                
                                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.blue/*@END_MENU_TOKEN@*/)
                                .cornerRadius(/*@START_MENU_TOKEN@*/20.0/*@END_MENU_TOKEN@*/)
                        }
                        .buttonStyle(BorderlessButtonStyle())
                        NavigationLink(destination: MeetingsDetailView(meetingNotes: "\(item.notes ?? "No notes")", detailMeetingName: "\(item.name ?? "Untitled")", detailMeetingLink: "\(item.link ?? "Undefined")",  detailMeetingTime: item.time!)) {
                                            
                        }
                        .frame(width: 10)
                    }
                }
                .onDelete(perform: deleteItems)
            }
            .listStyle(InsetListStyle())
            .navigationBarItems(
                leading: EditButton(),
                trailing:
                    Button {
                        self.isPresentingAddMeetingScreen.toggle()
                        print("Is Adding a New Meeting")
                    } label: {
                        Image(systemName: "plus")
                    })
            .navigationTitle("My Meetings")
            
            .background(EmptyView()
            .sheet(isPresented: $isShowingOnboardingScreen, content: {
                IntroductionView(isShowingOnboardingScreen: $isShowingOnboardingScreen)
                
            })
            )
                .sheet(isPresented: $showWhatsNew, content: {
                    WhatsNewView()
                })
                .onAppear(perform: checkForUpdate)
                .sheet(isPresented: $isPresentingAddMeetingScreen, content: {
                    AddANewMeeting(isPresented:
                        $isPresentingAddMeetingScreen)
                })
            }
        }
    }
    // MARK: Functions
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)
            do {
                try viewContext.save()
            } catch {
                print("There was an error deleting items")
            }
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.timeStyle = .short
    return formatter
}()

// MARK: Modal View

struct AddANewMeeting: View {
    
    struct StoreReviewHelper {
        
        
    }

    struct UserDefaultsKeys {
        static let APP_OPENED_COUNT = "APP_OPENED_COUNT"
    }


    
    
    struct TextFieldClearButton: ViewModifier {
        
        @Binding var text: String
    
        func body(content: Content) -> some View {
            HStack {
                content
                if !text.isEmpty {
                    Button(
                        action: { self.text = "" },
                        label: {
                            Image(systemName: "multiply.circle.fill")
                                .foregroundColor(Color(UIColor.opaqueSeparator))
                        }
                    )
                }
            }
        }
    }
    
    @Environment(\.managedObjectContext) private var viewContext
    // Using CoreData managed object
    @Binding var isPresented: Bool
    // Helping Add a New Meeting View
    @State var meetingName = ""
    @State var meetingLink = ""
    @State var meetingID = ""
    @State var meetingTime = Date()
    // ^^ State variables for form
    
    @State private var addMeetingStyle = false
    // State variable for Meeting URL or Meeting ID
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Meeting Information"), footer: Text("If you're using a meeting link, make sure it's a URL. If you only have a Zoom meeting ID, that works also. ")) {
                    TextField("Meeting Name", text: $meetingName)
                        .autocapitalization(.words)
                        .modifier(TextFieldClearButton(text: $meetingName))
                        .disableAutocorrection(true)
                    Picker(selection: $addMeetingStyle, label: Text("Choose a way to add meeting information")) {
                                    Text("Link (URL)").tag(false)
                                    Text("Meeting ID (Zoom)").tag(true)
                                }
                                .pickerStyle(SegmentedPickerStyle())
                    if addMeetingStyle == true {
                        TextField("Meeting ID", text: $meetingID)
                            .keyboardType(.numberPad)
                    } else if addMeetingStyle == false {
                        TextField("Meeting Link", text: $meetingLink)
                            .modifier(TextFieldClearButton(text: $meetingLink))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                    }
                }
                Section(header: Text("Meeting Time")) {
                    DatePicker("Meeting Time", selection: $meetingTime, displayedComponents: [.hourAndMinute])
                }
            }
            .navigationBarTitle("Add a New Meeting", displayMode: .inline)
            .navigationBarItems(leading: Button {
                self.isPresented = false
                print("Cancelled 'Add Meeting'")
            } label: {
                Text("Cancel")
            }, trailing: Button {
            
                guard self.meetingName != "" else {return}
                // Ensure Meeting Name has a value
                let newMeeting = Item(context: viewContext)
                newMeeting.name = self.meetingName
                newMeeting.time = self.meetingTime
                if meetingLink == "" {
                    newMeeting.link = "https://www.zoom.us/j/\(self.meetingID)"
                } else {
                    newMeeting.link = self.meetingLink
                }
                // Logic for choosing between Meeting ID and Meeting Link
                do {
                        try viewContext.save()
                        print("New Meeting Created")
                    } catch {
                        print(error.localizedDescription)
                    }
                self.isPresented = false
                // Closes Add A New Meeting View
            } label: {
                Text("Create")
            })
            
        }
    }
}

// MARK: Preview Provider
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
        AddANewMeeting(isPresented: Binding.constant(true))
    }
}

 */

//
//  RepeatRow.swift
//  Zoom
//
//  Created by Benjamin Who on 2/18/21.
//

import SwiftUI
import Foundation
import CoreData

struct RepeatRow: View {
    
    @Environment(\.openURL) var openURL
    
    @Environment(\.managedObjectContext) private var viewContext
    
    var meeting: RepeatingItem
    
    
    var body: some View {
        HStack {
            VStack(alignment: .leading){
                Text("\(self.meeting.name ?? "Untitled")")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .padding(.top, 5.0)
                    .padding(.bottom, 0)
                if meeting.repeats == "1" {
                    Text("Sundays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "2" {
                    Text("Mondays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "3" {
                    Text("Tuesdays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "4" {
                Text("Wednesdays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                    .foregroundColor(Color.gray)
                    .padding(.bottom, 3.0)
                    .padding(.top, -3)
                } else if meeting.repeats == "5" {
                    Text("Thursdays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "6" {
                    Text("Fridays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "7" {
                    Text("Saturdays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "8" {
                    Text("Weekdays at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "9" {
                    Text("Weekends at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else if meeting.repeats == "10" {
                    Text("Every day at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                } else {
                    EmptyView()
                }
            }
            Spacer()
            Button {
                print("Sending to computer")
                guard let data = URL(string: "\(self.meeting.link ?? "undefined")") else { return }
                let av = UIActivityViewController(activityItems: [data], applicationActivities: nil)
                UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .font(.title3)
                    .padding(.trailing, 10)
            }
            .buttonStyle(BorderlessButtonStyle())
            Button {
                print("Joining on iPhone")
                openURL(URL(string: "\(self.meeting.link ?? "untitled")")!)
            } label: {
                Text("JOIN")
                    .fontWeight(.semibold)
                    .foregroundColor(Color.white)
                    .frame(width: 60.0, height: 30.0)
                    .padding(.trailing, 1.0)
                    
                    .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.blue/*@END_MENU_TOKEN@*/)
                    .cornerRadius(/*@START_MENU_TOKEN@*/20.0/*@END_MENU_TOKEN@*/)
            }
            .buttonStyle(BorderlessButtonStyle())
            NavigationLink(destination: RepeatDetailView(audioRecorder: AudioRecorder(), meeting: meeting)) {
                                
            }
            .frame(width: 10)
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.timeStyle = .short
    return formatter
}()

struct RepeatRow_Previews: PreviewProvider {
    
    static let moc = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
    
    static var previews: some View {
        let meeting = RepeatingItem(context: moc)
        meeting.name = "Test Meeting"
        meeting.link = "https://www.zoom.com"
        meeting.time = Date()
        meeting.notes = "These are a lot of ntoes that I took for this meeting. There's prolly some typos but that doesn't really matter because we're in preview mode and this doesn't reflect in the final content."
        
        
        return NavigationView {
            RepeatRow(meeting: meeting)
        }
    }
}

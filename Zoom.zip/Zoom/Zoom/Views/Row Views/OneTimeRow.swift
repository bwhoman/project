//
//  OneTimeRow.swift
//  Zoom
//
//  Created by Benjamin Who on 2/17/21.
//

import SwiftUI
import Foundation
import CoreData

struct OneTimeRow: View {
    
    @Environment(\.openURL) var openURL
    
    @Environment(\.managedObjectContext) private var viewContext
    
    var meeting: Item
   
    /*
    var oneTimeName: String
    var oneTimeLink: String?
    var oneTimeDate: Date?
    var oneTimeNotes: String?
    */
    let calendar = Calendar.current
    
    var body: some View {
        HStack {
            VStack(alignment: .leading){
                Text("\(self.meeting.name ?? "Untitled")")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .padding(.top, 5.0)
                    .padding(.bottom, 0)
                
                
                if calendar.isDateInToday(self.meeting.time ?? Date()) {
                    Text("Today at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                } else if calendar.isDateInYesterday(self.meeting.time ?? Date()){
                    Text("Yesterday at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                } else if calendar.isDateInTomorrow(self.meeting.time ?? Date()) {
                    Text("Tomorrow at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                } else {
                    Text("\(self.meeting.time ?? Date(), formatter: showDayFormatter) at \(self.meeting.time ?? Date(), formatter: itemFormatter)")
                        .foregroundColor(Color.gray)
                        .padding(.bottom, 3.0)
                        .padding(.top, -3)
                }
                
            }
            
            Spacer()
            Button {
                print("Sending to computer")
                guard let data = URL(string: "\(self.meeting.link ?? "undefined")") else { return }
                let av = UIActivityViewController(activityItems: [data], applicationActivities: nil)
                UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .font(.title3)
                    .padding(.trailing, 10)
            }
            .buttonStyle(BorderlessButtonStyle())
            Button {
                print("Joining on iPhone")
                openURL(URL(string: "\(self.meeting.link ?? "untitled")")!)
            } label: {
                Text("JOIN")
                    .fontWeight(.semibold)
                    .foregroundColor(Color.white)
                    .frame(width: 60.0, height: 30.0)
                    .padding(.trailing, 1.0)
                    
                    .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.blue/*@END_MENU_TOKEN@*/)
                    .cornerRadius(20.0)
            }
            .buttonStyle(BorderlessButtonStyle())
            NavigationLink(destination: MeetingsDetailView(audioRecorder: AudioRecorder(), meeting: meeting)) {
                                
            }
            .frame(width: 10)
        }

    }
    
}


private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.timeStyle = .short
    return formatter
}()

private let showDayFormatter: DateFormatter = {
    
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    return formatter
}()

struct OneTimeRow_Previews: PreviewProvider {
    
    static let moc = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
    
    static var previews: some View {
        let meeting = Item(context: moc)
        meeting.name = "Test Meeting"
        meeting.link = "https://www.zoom.com"
        meeting.time = Date()
        meeting.notes = "These are a lot of ntoes that I took for this meeting. There's prolly some typos but that doesn't really matter because we're in preview mode and this doesn't reflect in the final content."
        
        
        return NavigationView {
            OneTimeRow(meeting: meeting)
        }
    }
}

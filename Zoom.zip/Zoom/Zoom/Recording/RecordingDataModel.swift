//
//  RecordingDataModel.swift
//  Zoom
//
//  Created by Benjamin Who on 2/19/21.
//

import Foundation

struct Recording {
    let fileURL: URL
    let createdAt: Date
}



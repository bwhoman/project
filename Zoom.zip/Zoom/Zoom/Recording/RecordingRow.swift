//
//  RecordingRow.swift
//  Zoom
//
//  Created by Benjamin Who on 2/19/21.
//

import SwiftUI

struct RecordingRow: View {
    
    var audioURL: URL
    
    @ObservedObject var audioPlayer = AudioPlayer()
    
    

    var body: some View {
        HStack {
            if audioPlayer.isPlaying == false {
                Button(action: {
                    print("Start playing audio")
                    self.audioPlayer.startPlayback(audio: self.audioURL)
                }) {
                    Image(systemName: "play.fill")
                        .imageScale(.large)
                }.buttonStyle(BorderlessButtonStyle())
            } else {
                Button(action: {
                    print("Stop playing audio")
                    self.audioPlayer.stopPlayback()
                }) {
                    Image(systemName: "stop.fill")
                        .imageScale(.large)
                }.buttonStyle(BorderlessButtonStyle())
            }
            Text("\(audioURL.lastPathComponent)")
            Spacer()
            Button {
                actionSheet()
            } label: {
                Image(systemName: "square.and.arrow.up")
            }.buttonStyle(BorderlessButtonStyle())
        }
    }
    
    func actionSheet() {
        let data = audioURL
        let av = UIActivityViewController(activityItems: [data], applicationActivities: nil)
        UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)
    }
}



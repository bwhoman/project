//
//  OnboardingScreen.swift
//  Zoom
//
//  Created by Benjamin Who on 2/12/21.
//

import SwiftUI
import UIKit


struct ButtonModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .foregroundColor(.white)
            .font(.headline)
            .padding()
            .frame(minWidth: 0, maxWidth: .infinity, alignment: .center)
            .background(RoundedRectangle(cornerRadius: 15, style: .continuous)
                .fill(Color.mainColor))
            .padding(.bottom)
    }
}

extension View {
    func customButton() -> ModifiedContent<Self, ButtonModifier> {
        return modifier(ButtonModifier())
    }
}

extension Text {
    func customTitleText() -> Text {
        self
            .fontWeight(.black)
            .font(.system(size: 36))
    }
}

extension Color {
    static var mainColor = Color(UIColor.systemIndigo)
}


struct InformationDetailView: View {
    var title: String = "title"
    var subTitle: String = "subTitle"
    var imageName: String = "car"

    var body: some View {
        HStack(alignment: .center) {
            Image(systemName: imageName)
                .frame(width: 30.0)
                .font(.largeTitle)
                .foregroundColor(.accentColor)
                .padding()
                .accessibility(hidden: true)

            VStack(alignment: .leading) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .accessibility(addTraits: .isHeader)
                    

                Text(subTitle)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.top)
    }
}

struct InformationContainerView: View {
    var body: some View {
        VStack(alignment: .leading) {
            InformationDetailView(title: "Manage your meetings", subTitle: "Meetings is a beautiful app that lets you manage your virtual meetings with ease. You can add meetings using a URL, a Zoom meeting ID, or a Google Meet ID - it's that simple. ", imageName: "doc.plaintext")

            InformationDetailView(title: "Powerful management", subTitle: "Meetings comes packed with tools to make your life easier. You can save notes about a meeting or even record one using the Recording Studio. Just tap on a meeting to discover these tools.", imageName: "gearshape.2")

            InformationDetailView(title: "Always here", subTitle: "Now with iCloud, your meetings, notes, and recordings automatically sync across devices.", imageName: "icloud")
            
            InformationDetailView(title: "Stay on track", subTitle: "Meetings won't let you miss anything. You'll receive notifications five minutes before each one-time meeting.", imageName: "app.badge")
        }
        .padding(.horizontal)
    }
}

struct TitleView: View {
    var body: some View {
        VStack {
            Image("AppImage")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 130, alignment: .center)
                .accessibility(hidden: true)

            Text("Welcome to")
                .customTitleText()
                

            Text("Meetings")
                .customTitleText()
                .foregroundColor(.mainColor)
        }
    }
}

struct IntroductionView: View {
    
    @Binding var isShowingIntroScreen: Bool
    
    var body: some View {
        
            VStack {

                Spacer()
                    .frame(height: 20)
                ScrollView {
                TitleView()
                Spacer()
                
                InformationContainerView()
                
                Spacer()
                }
                    Button {
                        self.isShowingIntroScreen = false
                        print(123)
                        }
                    label: {
                        Text("Get started")
                            .customButton()
                    }
                
                
                .padding()
                
                Spacer()
                    .frame(height: 0)
            }
    }
}





struct OnboardingScreen_Previews: PreviewProvider {
    static var previews: some View {
        IntroductionView(isShowingIntroScreen: Binding.constant(true))
        InformationContainerView()
    }
}

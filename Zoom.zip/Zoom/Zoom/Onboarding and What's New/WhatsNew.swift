//
//  WhatsNew.swift
//  Zoom
//
//  Created by Benjamin Who on 2/14/21.
//

import SwiftUI

struct WhatsNewButtonModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .foregroundColor(.white)
            .font(.headline)
            .padding()
            .frame(minWidth: 0, maxWidth: .infinity, alignment: .center)
            .background(RoundedRectangle(cornerRadius: 15, style: .continuous)
                .fill(Color.mainColor))
            .padding(.bottom)
    }
}

struct WhatsNewInformationDetailView: View {
    var title: String = "title"
    var subTitle: String = "subTitle"
    var imageName: String = "car"

    var body: some View {
        HStack(alignment: .center) {
            Image(systemName: imageName)
                .frame(width: 30.0)
                .font(.largeTitle)
                .foregroundColor(.accentColor)
                .padding()
                .accessibility(hidden: true)

            VStack(alignment: .leading) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .accessibility(addTraits: .isHeader)
                    

                Text(subTitle)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.top)
    }
}

struct WhatsNewInformationContainerView: View {
    var body: some View {
        VStack(alignment: .leading) {
            InformationDetailView(title: "Recording Studio", subTitle: "Need to record an important meeting? With the Recording Studio, you can record all your meetings with high-fidelity audio and play them back right from your iPhone. Or share them as MP4 files.", imageName: "largecircle.fill.circle")
            
            InformationDetailView(title: "Meeting notes", subTitle: "Write down tasks to do before a meeting, or take notes during a meeting. Your notes are stored in iCloud and synced across devices.", imageName: "note.text")
            
            InformationDetailView(title: "Notifications", subTitle: "Meetings will now alert you when a one-time meeting is about to start.", imageName: "app.badge")

            InformationDetailView(title: "Editing a meeting", subTitle: "You can now edit all information about a meeting after you've created it.", imageName: "pencil")
        }
        .padding(.horizontal)
    }
}

struct WhatsNewTitleView: View {
    var body: some View {
        VStack {
            Image("AppImage")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 130, alignment: .center)
                .accessibility(hidden: true)

            Text("What's new to")
                .customTitleText()
                

            Text("Meetings")
                .customTitleText()
                .foregroundColor(.mainColor)
        }
    }
}

struct WhatsNewView: View {
    
    
    @Binding var showWhatsNew: Bool

    
    var body: some View {
        
            VStack {

                Spacer()
                    .frame(height: 20)
                ScrollView {
                WhatsNewTitleView()
                Spacer()
                
                WhatsNewInformationContainerView()
                
                Spacer()
                }
                    Button(action: {
                        self.showWhatsNew = false
                        }
                    ) {
                        Text("Continue")
                            .customButton()
                    }
                
                
                .padding()
                
                Spacer()
                    .frame(height: 0)
            }
    }
}



struct WhatsNew_Previews: PreviewProvider {
    static var previews: some View {
        WhatsNewView(showWhatsNew: Binding.constant(true))
    }
}

//
//  ZoomApp.swift
//  Zoom
//
//  Created by Benjamin Who on 2/12/21.
//

import SwiftUI

@main
struct ZoomApp: App {
    let persistenceController = PersistenceController.shared
    

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}

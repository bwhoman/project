//
//  Persistence.swift
//  Zoom
//
//  Created by Benjamin Who on 2/12/21.
//

import CoreData

struct PersistenceController {
    static let shared = PersistenceController()

    static var preview: PersistenceController = {
        let result = PersistenceController(inMemory: true)
        let viewContext = result.container.viewContext
        viewContext.automaticallyMergesChangesFromParent = true
        for _ in 0..<5 {
            let newItem = Item(context: viewContext)
            newItem.time = Date()
            newItem.name = "Sample Meeting"
            newItem.link = "https://www.apple.com/"
            newItem.notes = ""
        }
        do {
            try viewContext.save()
        } catch {
            print(error.localizedDescription)
        }
        
        
        return result
    }()

    let container: NSPersistentCloudKitContainer

    init(inMemory: Bool = false) {
        container = NSPersistentCloudKitContainer(name: "Zoom")
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                print(error.localizedDescription)
            }
        })
        
        container.viewContext.automaticallyMergesChangesFromParent = true
            container.viewContext.mergePolicy = NSMergeByPropertyStoreTrumpMergePolicy
    }
}
